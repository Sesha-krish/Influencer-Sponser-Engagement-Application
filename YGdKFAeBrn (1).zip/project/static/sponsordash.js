function viewCampaignDetails(campaignId) {
    // Fetch and display campaign details in a modal
}

function viewAdRequestDetails(adRequestId) {
    // Fetch and display ad request details in a modal
}

function acceptAdRequest(adRequestId) {
    // Send AJAX request to accept the ad request
}
